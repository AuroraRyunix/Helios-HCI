# Helios-HCI Update Package (Build 1.2.0-b4082)

This package contains updates for the core scheduler and HA controller:

## Components Included
- **Vali (Acropolis scheduler)**: Optimized live-migration placement calculations.
- **Mipha (HA Manager)**: Faster node heartbeat detection and VM recovery failover times.

## Change History
- Improved VM scheduling performance during node evacuations.
- Fixed a telemetry race condition on host network tap changes.
